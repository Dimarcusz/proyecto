# backendproject
BACKEND del PROYECTO Progra Movil 

FORMATO ARCHIVO .env
NODE_ENV = "development"
PORT = 3000
DB_USER=root
DATABASE=backenddata
DB_HOST=127.0.0.1
DB_PORT=3306
DB_PASSWORD=

CREAR TABLAS EN OTRA PC
npx sequelize-cli db:migrate

CLOUDINARY PONER EN EL .env


